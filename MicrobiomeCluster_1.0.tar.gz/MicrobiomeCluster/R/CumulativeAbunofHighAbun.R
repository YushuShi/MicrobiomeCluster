CumulativeAbunofHighAbun<-function(otuabundance){
  avgabun<-apply(otuabundance,1,mean)
  avgabun<-avgabun[avgabun>0.001]
  sum(avgabun)
}