#ifndef ClusterUpdateMFM_h
#define ClusterUpdateMFM_h

#include<Rcpp.h>
using namespace Rcpp ;
void ClusterUpdateMFM(NumericMatrix X, IntegerVector c,  const IntegerVector gamma, double alpha1, double alpha2, double nu, double beta1, double beta2,double pargamma,double lambda);
#endif /* ClusterUpdateMFM_h */
