#ifndef logll2vs1_h
#define logll2vs1_h
#include<Rcpp.h>
using namespace Rcpp ;
double logll2vs1(const NumericVector Ni, const NumericVector Nl, const IntegerVector rev_gamma,const IntegerVector gamma, double alpha1, double alpha2,double beta1, double beta2);

double logll1vs2(const NumericVector Ni, const NumericVector Nl,const IntegerVector rev_gamma, const IntegerVector gamma, double alpha1, double alpha2, double beta1, double beta2);
#endif /* logll2vs1_h */
