#ifndef likelihoodratio_h
#define likelihoodratio_h
#include<Rcpp.h>
using namespace Rcpp ;
double likelihoodratio(NumericMatrix X, const IntegerVector c, const IntegerVector gamma_old, const IntegerVector gamma_new, double alpha1, double alpha2, double beta1, double beta2);

#endif /* likelihoodratio_h */
