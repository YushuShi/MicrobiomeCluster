#include <vector>
#include <Rmath.h>
#include <R.h>
#include <algorithm>
#include <math.h>
#include <Rcpp.h>

using namespace Rcpp;
#include "auxiliaryfuncs.h"
#include "logll2vs1.h"
#include "MFM.h"

void ClusterUpdateMFM(NumericMatrix X, IntegerVector c,  const IntegerVector gamma, double alpha1, double alpha2, double nu, double beta1, double beta2,double pargamma,double lambda){
    IntegerVector aux(gamma.size(),1);
    IntegerVector rev_gamma=aux-gamma;
    IntegerVector cho2=choose2(c.size());
	// i and l can be 0
    int i=cho2[0];
    int l=cho2[1];
    int p;
    IntegerVector indicator=seq_len(c.size());
    IntegerVector combinedpool=indicator[(c==c[i])|(c==c[l])];
	double paddingvalue=0.0;
	//indicator starts from 1
	// combinedpool are the observations in the same cluster with i and l, including i and l
	
	//simple split and merge
	IntegerVector uc=unique(c);
    if(combinedpool.size()==2){
		paddingvalue=-log(pargamma+1.0)+log(pargamma)-logV(pargamma,c.size(),uc.size(),lambda)+
			logV(pargamma,c.size(),uc.size()+1,lambda);
        if(c[i]==c[l]){
			//Two vs One
            p=exp(paddingvalue+logll2vs1(X(_,i),X(_,l),rev_gamma,gamma,alpha1, alpha2,beta1,beta2));
            if(Rf_rbinom(1,min(1,p))>0.0){
                c[i]=max(c)+1;
            }
        }else{
            p=exp(-paddingvalue+logll1vs2(X(_,i),X(_,l),rev_gamma,gamma,alpha1, alpha2,beta1,beta2));
            if(Rf_rbinom(1,min(1,p))>0.0){
                c[i]=c[l];
            }
        }
    }else{
		//restricted sampling split and merge
        double part1=0.0;
        double part2=0.0;
        IntegerVector modcomb(clone(combinedpool));
        modcomb=modcomb[modcomb!=(i+1)];
        modcomb=modcomb[modcomb!=(l+1)];
		
		// modcomb are the ones in the same cluster but are not i or l
		// modcomb starts from 1
        IntegerVector cklaunch=ifelse(rbinom(modcomb.size(),1,0.5)==1,1,0);
		IntegerVector padding0=ifelse(rbinom(modcomb.size(),1,1.0)==1,1,0);
		IntegerVector padding1=modcomb-padding0;
		IntegerVector padding2=c[padding1];
        IntegerVector origsplit=ifelse(padding2==c[i],1,0);
		// original split ci is 1 cl is 0
        int t=5;
   // t intermediate states
        for(int j=0; j<t; j++){
            for(int enum1 = 0; enum1<cklaunch.size(); enum1++){
                IntegerVector modcombsub(clone(modcomb));
                modcombsub.erase(modcombsub.begin()+enum1);
                IntegerVector csub(clone(cklaunch));
                csub.erase(csub.begin()+enum1);
				//modcombsub is the real index of the observation 
				//csub is the launchstate
				
                double weight1=sum(csub==1)+1.0;
                double weight2=sum(csub==0)+1.0;
                IntegerVector temp1=modcombsub[csub==1];
                IntegerVector temp2=modcombsub[csub==0];
                NumericMatrix imat=cbindv(subsetcolind(X,temp1),X(_,i));
                NumericMatrix lmat=cbindv(subsetcolind(X,temp2),X(_,l));
                
                NumericVector ipar=rowsum(imat);
                NumericVector lpar=rowsum(lmat);
                NumericVector kvec=X(_,modcomb[enum1]-1);
                NumericVector kvecnotint=kvec[rev_gamma>0];
                NumericVector kvecint=kvec[gamma>0];
                NumericVector iparint=addconst(ipar[gamma>0],alpha2);
                NumericVector lparint=addconst(lpar[gamma>0],alpha2);
                NumericVector ipargamma=ipar[gamma>0];
                NumericVector lpargamma=lpar[gamma>0];
                NumericVector iparrevgamma=ipar[rev_gamma>0];
                NumericVector lparrevgamma=lpar[rev_gamma>0];
                double li=lgamma(sum(iparint))-lgamma(sum(kvecint)+sum(iparint));
                double ll=lgamma(sum(lparint))-lgamma(sum(kvecint)+sum(lparint));
                for(int enum2=0; enum2<iparint.size();enum2++){
                    li+=lgamma(kvecint[enum2]+iparint[enum2])-lgamma(iparint[enum2]);
                    ll+=lgamma(kvecint[enum2]+lparint[enum2])-lgamma(lparint[enum2]);
                }
                li+=lgamma(beta1+beta2+sum(ipar))-lgamma(beta1+sum(iparrevgamma))-lgamma(beta2+sum(ipargamma))+
                lgamma(beta1+sum(iparrevgamma)+sum(kvecnotint))+lgamma(beta2+sum(ipargamma)+sum(kvecint))
                -lgamma(beta1+beta2+sum(ipar)+sum(kvec));
                ll+=lgamma(beta1+beta2+sum(lpar))-lgamma(beta1+sum(lparrevgamma))-lgamma(beta2+sum(lpargamma))+
                lgamma(beta1+sum(lparrevgamma)+sum(kvecnotint))+lgamma(beta2+sum(lpargamma)+sum(kvecint))
                -lgamma(beta1+beta2+sum(lpar)+sum(kvec));
				double lprobi=log(weight1)-log(weight1+weight2*exp(ll-li));                
                int dice=Rf_rbinom(1,exp(lprobi));
                    if(dice>0){
                        cklaunch[enum1]=1;
                    }else{
                        cklaunch[enum1]=0;
                    }
            }
        }
            long double transp=0.0;
            if(c[i]==c[l]){
				//split
                for(int enum4 = 0; enum4<cklaunch.size(); enum4++){
                    IntegerVector modcombsub(clone(modcomb));
                    modcombsub.erase(modcombsub.begin()+enum4);
                    IntegerVector csub(clone(cklaunch));
                    csub.erase(csub.begin()+enum4);
                    double weight1=sum(csub==1)+1.0;
                    double weight2=sum(csub==0)+1.0;
                    IntegerVector temp1=modcombsub[csub==1];
                    IntegerVector temp2=modcombsub[csub==0];

                    NumericMatrix imat=cbindv(subsetcolind(X,temp1),X(_,i));
                    NumericMatrix lmat=cbindv(subsetcolind(X,temp2),X(_,l));
                    NumericVector ipar=rowsum(imat);
                    NumericVector lpar=rowsum(lmat);
                    NumericVector kvec=X(_,modcomb[enum4]-1);
                    NumericVector kvecnotint=kvec[rev_gamma>0];
                    NumericVector kvecint=kvec[gamma>0];
                    NumericVector iparint=addconst(ipar[gamma>0],alpha2);
                    NumericVector lparint=addconst(lpar[gamma>0],alpha2);
                    NumericVector ipargamma=ipar[gamma>0];
                    NumericVector lpargamma=lpar[gamma>0];
                    NumericVector iparrevgamma=ipar[rev_gamma>0];
                    NumericVector lparrevgamma=lpar[rev_gamma>0];
                    double li=lgamma(sum(iparint))-lgamma(sum(kvecint)+sum(iparint));
                    double ll=lgamma(sum(lparint))-lgamma(sum(kvecint)+sum(lparint));
                    for(int enum2=0; enum2<iparint.size();enum2++){
                        li+=lgamma(kvecint[enum2]+iparint[enum2])-lgamma(iparint[enum2]);
                        ll+=lgamma(kvecint[enum2]+lparint[enum2])-lgamma(lparint[enum2]);
                    }
                    li+=lgamma(beta1+beta2+sum(ipar))-lgamma(beta1+sum(iparrevgamma))-lgamma(beta2+sum(ipargamma))+
                    lgamma(beta1+sum(iparrevgamma)+sum(kvecnotint))+lgamma(beta2+sum(ipargamma)+sum(kvecint))
                    -lgamma(beta1+beta2+sum(ipar)+sum(kvec));
                    ll+=lgamma(beta1+beta2+sum(lpar))-lgamma(beta1+sum(lparrevgamma))-lgamma(beta2+sum(lpargamma))+
                    lgamma(beta1+sum(lparrevgamma)+sum(kvecnotint))+lgamma(beta2+sum(lpargamma)+sum(kvecint))
                    -lgamma(beta1+beta2+sum(lpar)+sum(kvec));
					double lprobi=log(weight1)-log(weight1+weight2*exp(ll-li));
                    double lprobl=log(weight2)-log(weight1*exp(li-ll)+weight2);				
                    int dice=Rf_rbinom(1,exp(lprobi));
                    if(dice>0){
                        cklaunch[enum4]=1;
						 transp+=lprobi;

                    }else{
                        cklaunch[enum4]=0;
                        transp+=lprobl;
                    }
                }
            }else{
				//merge
                for(int enum4 = 0; enum4<cklaunch.size(); enum4++){
                    IntegerVector modcombsub(clone(modcomb));
                    modcombsub.erase(modcombsub.begin()+enum4);
                    IntegerVector csub(clone(origsplit));
                    csub.erase(csub.begin()+enum4);
                    double weight1=sum(csub==1)+1.0;
                    double weight2=sum(csub==0)+1.0;
                    IntegerVector temp1=modcombsub[csub==1];
                    IntegerVector temp2=modcombsub[csub==0];

                    NumericMatrix imat=cbindv(subsetcolind(X,temp1),X(_,i));
                    NumericMatrix lmat=cbindv(subsetcolind(X,temp2),X(_,l));
                    NumericVector ipar=rowsum(imat);
                    NumericVector lpar=rowsum(lmat);
                    NumericVector kvec=X(_,modcomb[enum4]-1);
                    NumericVector kvecnotint=kvec[rev_gamma>0];
                    NumericVector kvecint=kvec[gamma>0];
                    NumericVector iparint=addconst(ipar[gamma>0],alpha2);
                    NumericVector lparint=addconst(lpar[gamma>0],alpha2);
                    NumericVector ipargamma=ipar[gamma>0];
                    NumericVector lpargamma=lpar[gamma>0];
                    NumericVector iparrevgamma=ipar[rev_gamma>0];
                    NumericVector lparrevgamma=lpar[rev_gamma>0];
                    double li=lgamma(sum(iparint))-lgamma(sum(kvecint)+sum(iparint));
                    double ll=lgamma(sum(lparint))-lgamma(sum(kvecint)+sum(lparint));
                    for(int enum2=0; enum2<iparint.size();enum2++){
                        li+=lgamma(kvecint[enum2]+iparint[enum2])-lgamma(iparint[enum2]);
                        ll+=lgamma(kvecint[enum2]+lparint[enum2])-lgamma(lparint[enum2]);
                    }
                    li+=lgamma(beta1+beta2+sum(ipar))-lgamma(beta1+sum(iparrevgamma))-lgamma(beta2+sum(ipargamma))+
                    lgamma(beta1+sum(iparrevgamma)+sum(kvecnotint))+lgamma(beta2+sum(ipargamma)+sum(kvecint))
                    -lgamma(beta1+beta2+sum(ipar)+sum(kvec));
                    ll+=lgamma(beta1+beta2+sum(lpar))-lgamma(beta1+sum(lparrevgamma))-lgamma(beta2+sum(lpargamma))+
                    lgamma(beta1+sum(lparrevgamma)+sum(kvecnotint))+lgamma(beta2+sum(lpargamma)+sum(kvecint))
                    -lgamma(beta1+beta2+sum(lpar)+sum(kvec));
					double lprobi=log(weight1)-log(weight1+weight2*exp(ll-li));
                    double lprobl=log(weight2)-log(weight1*exp(li-ll)+weight2);				

                    if(cklaunch[enum4]==1){
                        transp+=lprobi;
                    }else{
                        transp+=lprobl;
                    }
                }
            }
        IntegerVector index1(1,i+1);
        IntegerVector index2(1,l+1);
        for(int enum3=0; enum3<cklaunch.size(); enum3++){
			if(c[i]==c[l]){
				if(cklaunch[enum3]==1){
					index1.push_back(modcomb[enum3]);
				}else{
					index2.push_back(modcomb[enum3]);
				}
			}else{
				if(c[modcomb[enum3]-1]==c[i]){
					index1.push_back(modcomb[enum3]);
				}else{
					index2.push_back(modcomb[enum3]);
				}	
			}
        }
		
        paddingvalue=-lgamma(pargamma+index1.size()+index2.size())-lgamma(pargamma)+lgamma(pargamma+index1.size())+lgamma(pargamma+index2.size())-logV(pargamma,c.size(),uc.size(),lambda)+logV(pargamma,c.size(),uc.size()+1,lambda);
        if(c[i]==c[l]){
            part1=-transp;
            part2=paddingvalue;
        }else{
            part1=transp;
            part2=-paddingvalue;
        }
        double ll2vs1=lgamma(beta1+beta2)-lgamma(beta1)-lgamma(beta2)+lgamma(sum(gamma)*alpha2)-sum(gamma)*lgamma(alpha2);
	
		NumericMatrix Xsub1=subsetcolind(X,index1);
        NumericMatrix Xsub2=subsetcolind(X,index2);
        NumericMatrix Xsub=subsetcolind(X,combinedpool);
        NumericVector Xsubrow=rowsum(Xsub);
        NumericVector Xsub1row=rowsum(Xsub1);
        NumericVector Xsub2row=rowsum(Xsub2);
        NumericVector Xsub1rowrev_gamma=Xsub1row[rev_gamma>0];
        NumericVector Xsub2rowrev_gamma=Xsub2row[rev_gamma>0];
        NumericVector Xsubrowrev_gamma=Xsubrow[rev_gamma>0];
        NumericVector Xsub1rowgamma=Xsub1row[gamma>0];
        NumericVector Xsub2rowgamma=Xsub2row[gamma>0];
        NumericVector Xsubrowgamma=Xsubrow[gamma>0];
        ll2vs1+=lgamma(sum(Xsubrowgamma)+sum(gamma)*alpha2)-lgamma(sum(Xsub1rowgamma)+sum(gamma)*alpha2)-lgamma(sum(Xsub2rowgamma)+sum(gamma)*alpha2)
        +lgamma(sum(Xsub1rowrev_gamma)+beta1)+lgamma(sum(Xsub1rowgamma)+beta2)-lgamma(sum(Xsub1row)+beta1+beta2)
        +lgamma(sum(Xsub2rowrev_gamma)+beta1)+lgamma(sum(Xsub2rowgamma)+beta2)-lgamma(sum(Xsub2row)+beta1+beta2)
        -lgamma(sum(Xsubrowrev_gamma)+beta1)-lgamma(sum(Xsubrowgamma)+beta2)+lgamma(sum(Xsubrow)+beta1+beta2);
        double temp1=-lgamma(sum(Xsub1rowgamma)+sum(gamma)*alpha2);
		double temp2=-lgamma(sum(Xsub2rowgamma)+sum(gamma)*alpha2);
		double temp3=lgamma(sum(Xsubrowgamma)+sum(gamma)*alpha2);
		for(int enum4=0; enum4<sum(gamma);enum4++){
            ll2vs1+=lgamma(Xsub1rowgamma[enum4]+alpha2)+lgamma(Xsub2rowgamma[enum4]+alpha2)-lgamma(Xsubrowgamma[enum4]+alpha2);
            temp1+=lgamma(Xsub1rowgamma[enum4]+alpha2);
			temp2+=lgamma(Xsub2rowgamma[enum4]+alpha2);
			temp3-=lgamma(Xsubrowgamma[enum4]+alpha2);
		}
		
        double prob;
        if(c[i]==c[l]){
            prob=min(1.0,exp(part1+part2+ll2vs1));
        }else{
            prob=min(1.0,exp(part1+part2-ll2vs1));
		}
        if(Rf_rbinom(1,prob)>0){
            if(c[i]==c[l]){
                c[i]=max(c)+1;
            }else{
                c[i]=c[l];
            }
            for(int enum5=0; enum5<cklaunch.size(); enum5++){
                    if(cklaunch[enum5]==1){
                     c[modcomb[enum5]-1]=c[i];
                    }else{
                     c[modcomb[enum5]-1]=c[l];
                    }
            }
        }
    }
}
