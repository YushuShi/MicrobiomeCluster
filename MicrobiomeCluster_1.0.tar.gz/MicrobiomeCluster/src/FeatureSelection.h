#ifndef FeatureSelection_h
#define FeatureSelection_h

#include<Rcpp.h>
using namespace Rcpp ;
void FeatureSelection(NumericMatrix X, IntegerVector c, IntegerVector gamma, double alpha1, double alpha2, double w, double beta1, double beta2);
#endif /* FeatureSelection_h */
