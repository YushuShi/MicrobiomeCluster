#include <vector>
#include <Rmath.h>
#include <R.h>
#include <algorithm>
#include <math.h>
#include <Rcpp.h>
using namespace Rcpp ;
double logll2vs1(const NumericVector Ni, const NumericVector Nl, const IntegerVector rev_gamma,const IntegerVector gamma, double alpha1, double alpha2,double beta1, double beta2){
	//Ni is the OTU numbers for obs i, Nl is the OTU numbers for obs l;
    NumericVector intNi=Ni[gamma>0];
    NumericVector intNl=Nl[gamma>0];
    NumericVector notintNi=Ni[rev_gamma>0];
    NumericVector notintNl=Nl[rev_gamma>0];
    
    double result=lgamma(sum(gamma)*alpha2)-sum(gamma)*lgamma(alpha2)
    +lgamma(beta1+beta2)-lgamma(beta1)-lgamma(beta2)
    +lgamma(beta1+sum(notintNi))+lgamma(beta2+sum(intNi))-lgamma(beta1+beta2+sum(Ni))
    +lgamma(beta1+sum(notintNl))+lgamma(beta2+sum(intNl))-lgamma(beta1+beta2+sum(Nl))
    -lgamma(beta1+sum(notintNi)+sum(notintNl))-lgamma(beta2+sum(intNi)+sum(intNl))+lgamma(beta1+beta2+sum(Ni)+sum(Nl))
    -lgamma(sum(intNl)+sum(gamma)*alpha2)-lgamma(sum(intNi)+sum(gamma)*alpha2)+lgamma(sum(intNl)+sum(intNi)+sum(gamma)*alpha2);

    for(int i=0; i<sum(gamma); i++){
        result+=lgamma(intNi[i]+alpha2)+lgamma(intNl[i]+alpha2)-lgamma(intNi[i]+intNl[i]+alpha2);
    }

    return result;
}

double logll1vs2(const NumericVector Ni, const NumericVector Nl,const IntegerVector rev_gamma, const IntegerVector gamma, double alpha1, double alpha2, double beta1, double beta2){
    return -logll2vs1(Ni, Nl, rev_gamma, gamma, alpha1, alpha2,beta1,beta2);
}
