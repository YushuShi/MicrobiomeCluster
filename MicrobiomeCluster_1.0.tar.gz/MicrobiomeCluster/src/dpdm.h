#ifndef dpdm_h
#define dpdm_h

#include <Rcpp.h>

using namespace Rcpp;
List dpdm(NumericMatrix X, IntegerVector c, IntegerVector gamma, double alpha1, double alpha2, double nu, double w, int totaliter,double a, double b, double beta1, double beta2);
#endif /* dpdm_h */
